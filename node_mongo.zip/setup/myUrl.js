module.exports = {
    mongoURL : 'mongodb+srv://test_mongo:test_mongo@cluster0.gjszyqw.mongodb.net/?retryWrites=true&w=majority',
    secret : 'mysrongsecret'
};