const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const port = process.env.PORT || 3000;
const app = express();

// bring all routes
const auth = require('./routes/api/auth');



// mongoDB configration
const db = require('./setup/myUrl').mongoURL;

mongoose.connect(db)
.then(()=> console.log('Connection Successfuly'))
.catch(err => console.log(err));





// middleware for bodyParser
app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json());

app.get('/' , (req,res)=>{
    res.send('Hello EveryOne');
    res.end();
})


// actual routes
app.use('/api/auth', auth);


app.listen(port,()=>console.log(`Server is running on port ${port}`))