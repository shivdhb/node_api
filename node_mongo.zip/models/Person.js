const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PersonSchema = new Schema({
    name:{
        type:String,
        require:true
    },
    email:{
        type:String,
        require:true,
    },
    password:{
        type:String,
        required:true
    },
    username:{
        type:String,
    },
    profilepic:{
        type:String,
        default:'https://img.freepik.com/free-photo/top-view-roses-flowers_23-2148860041.jpg?w=2000'
    },
    date:{
        type:String,
        default:Date.now
    }    
})

module.exports = Person = mongoose.model('myPerson',PersonSchema);